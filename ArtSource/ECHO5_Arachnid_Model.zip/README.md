# ECHO5_Arachnid — modelo original

Asset editable Blender 4.5.3 LTS, GLB, FBX, materiales Unity, render y generador completo.
Ocho patas rígidas articuladas, cuatro ojos cian y dos antenas. 1,064 m de ancho;
22.972 triángulos. Origen Chassis_Root en Z=0.

Ejecutar el script desde una instancia nueva de Blender:

blender --background --factory-startup --python Tools/build_arachnid.py -- --render

Este paquete contiene el modelo, no el agente ECHO ni el proyecto Unity completo.
La integración activa y la IK están en /home/roger/Unity/ECHO-Station; instrucciones
en Docs/Arachnid/README.md de ese proyecto. Las fuentes del pack Adventure Forge
no se han utilizado en este modelo. Véase ASSET-NOTICE.md en ArtSource.
